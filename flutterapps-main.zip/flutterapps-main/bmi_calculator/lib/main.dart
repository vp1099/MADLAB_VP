import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const appTitle = 'BMI Calculator';

    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
        ),
        body: const MyCustomForm(),
      ),
    );
  }
}

// Create a Form widget.
class MyCustomForm extends StatefulWidget {
  const MyCustomForm({Key? key}) : super(key: key);

  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

// Create a corresponding State class.
// This class holds data related to the form.
class MyCustomFormState extends State<MyCustomForm> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a GlobalKey<FormState>,
  // not a GlobalKey<MyCustomFormState>.
  final _formKey = GlobalKey<FormState>();
  double wt = 0, ht = 0;

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Form(
      key: _formKey,
      child:
      Container(
        margin: EdgeInsets.all(100.0),
        alignment: Alignment.center,
        child:
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 400.0,
              alignment: Alignment.center,
              height: 100.0,
              child:
              TextFormField(
                // The validator receives the text that the user has entered.
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Height (cm):'
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter some text';
                  }
                  try {
                    double i = double.parse(value);
                    if (i <= 0) {
                      return 'Invalid number!';
                    }
                    ht = i;
                  } catch (e) {
                    return 'Invalid number!';
                  }
                  return null;
                }
              ),
            ),
            Container(
              width: 400.0,
              alignment: Alignment.center,
              height: 100.0,
              child:
              TextFormField(
                // The validator receives the text that the user has entered.
                  decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      labelText: 'Weight (kg):'
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter some text';
                    }
                    try {
                      double i = double.parse(value);
                      if (i <= 0) {
                        return 'Invalid number!';
                      }
                      wt = i;
                    } catch (e) {
                      return 'Invalid number!';
                    }
                    return null;
                  }
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: ElevatedButton(
                onPressed: () {
                  // Validate returns true if the form is valid, or false otherwise.
                  if (_formKey.currentState!.validate()) {
                    // If the form is valid, display a snackbar. In the real world,
                    // you'd often call a server or save the information in a database.
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(getBMIDesc())),
                    );
                  }
                },
                child: const Text('Calculate BMI!'),
              ),
            ),
          ],
        ),
      )
    );
  }

  String getBMIDesc() {

    double bmi = (wt*100*100)/(ht*ht);
    String bmiDesc = "You are ";
    if (bmi < 18.5) bmiDesc += "underweight!";
    else if (bmi < 24.9) bmiDesc += "fit!";
    else if (bmi < 29.9) bmiDesc += "overwreight!";
    else bmiDesc += "obese!";

    bmiDesc += " Your BMI is " + bmi.toStringAsFixed(2) + '.';
    return bmiDesc;
  }
}