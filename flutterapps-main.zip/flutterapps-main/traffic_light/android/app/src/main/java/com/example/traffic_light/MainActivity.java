package com.example.traffic_light;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
