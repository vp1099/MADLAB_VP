import 'package:flutter/material.dart';
import 'images.dart';

void main() {
	runApp(MaterialApp(
		title: 'Images',
		home: Images(),
	));
}