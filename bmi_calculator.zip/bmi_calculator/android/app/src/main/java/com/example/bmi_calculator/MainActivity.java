package com.example.bmi_calculator;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
