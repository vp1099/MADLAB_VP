package com.example.loginwithdatabase;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText editTextEmail;
    EditText editTextPassword;
    Button buttonLogin, buttonRegister;
    SqliteHelper sqliteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sqliteHelper = new SqliteHelper(this);
        initViews();
        buttonRegister.setOnClickListener(view -> {
            String Email = editTextEmail.getText().toString();
            String Password = editTextPassword.getText().toString();
            User currentUser = new User(null, null, Email, Password);
            sqliteHelper.addUser(currentUser);
            Toast.makeText(getApplicationContext(), "Successfully added user!", Toast.LENGTH_LONG).show();
        });

        buttonLogin.setOnClickListener(view -> {
            if (validate()) {
                //Get values from EditText fields
                String Email = editTextEmail.getText().toString();
                String Password = editTextPassword.getText().toString();
                User currentUser = sqliteHelper.Authenticate(new User(null, null, Email, Password));
                if (currentUser != null) {
                    Toast.makeText(getApplicationContext(), "Authentication successful!", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Invalid user credentials!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void initViews() {
        editTextEmail = (EditText) findViewById(R.id.editEmail);
        editTextPassword = (EditText) findViewById(R.id.editPassword);
        buttonLogin = (Button) findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
    }
    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;
        //Get values from EditText fields
        String Email = editTextEmail.getText().toString();
        String Password = editTextPassword.getText().toString();

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            editTextEmail.setError("Please enter valid email!");
            return false;
        } else {
            editTextEmail.setError(null);
        }
        //Handling validation for Password field
        if (Password.isEmpty()) {
            editTextPassword.setError("Please enter valid password!");
        } else {
            if (Password.length() > 5) {
                valid = true;
                editTextPassword.setError(null);
            } else {
                editTextPassword.setError("Password is to short!");
                editTextPassword.setError("Password is to short!");
            }
        }
        return valid;
    }
}