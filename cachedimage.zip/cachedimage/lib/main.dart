import 'package:flutter/material.dart';
import 'localcache.dart';

void main() {
  runApp(MaterialApp(
    title: 'Images',
    home: LocalCache(),
  ));
}
